<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
<body>

    <div class="cotainer pt-5">
        <div class="row justify-content-center pt-5" >
            <div class="col-xl-6">
            <form action="<?php echo e(URL::to('update',$user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                
                <div class="form-group">
                    <label for="name">NAME</label>
                    <input type="name" class="form-control w-auto" id="name" value="<?php echo e($user->name); ?>" name="name">
                </div>

                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control w-auto" id="email" value="<?php echo e($user->email); ?>" name="email">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control w-auto" id="password" value="<?php echo e($user->password); ?>" name="password">
                </div>

                <div class="form-group">
                    <label for="phone">PHONE</label>
                    <input type="tel" class="form-control w-auto" id="phone" value="<?php echo e($user->phone); ?>" name="phone">
                </div>

                <button type="submit" class="btn btn-primary" name="submit">UPDATE</button>
            </form>
            <a href="/" class="btn btn-danger mt-3 mx-5">GO BACK</a>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\LARAVEL\CRUD_PRACTICE\example-app\resources\views/users/edit.blade.php ENDPATH**/ ?>