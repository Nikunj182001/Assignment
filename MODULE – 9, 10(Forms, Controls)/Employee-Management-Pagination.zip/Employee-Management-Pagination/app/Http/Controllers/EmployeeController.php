<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EmployeeController extends Controller
{
    function index()
    {
        $employee = DB::table('employees')->paginate(2);

        return view('index', compact('employee'));
    }

    function create()
    {
        return view('create');
    }

    function store(request $request)
    {
        $data = $request->all();

        $employee = DB::table('employees')->insert([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'age' => $data['age'],
            'address' => $data['address']
        ]);

        return redirect()->route('index');

    }

    function show($id)
    {
        $employee = DB::table('employees')->where('id', $id)->first();
        return view('show', compact('employee'));
    }

    function edit($id)
    {
        $employee = DB::table('employees')->where('id', $id)->first();
        return view('edit', compact('employee'));

    }
    function update($id, request $request)
    {
        $data = $request->all();
        $employee = DB::table('employees')
            ->where('id', $id)
            ->update([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => $data['password'],
                'age' => $data['age'],
                'address' => $data['address'],
            ]);

        return redirect()->route('index');

    }

    function delete($id)
    {
        $employee = DB::table('employees')->where('id', $id)->delete();

        return redirect()->route('index');
    }
}
